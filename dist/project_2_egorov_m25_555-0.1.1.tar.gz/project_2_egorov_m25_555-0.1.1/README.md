# Project #2 - Primitive Database
## Простая консольная база данных на Python с поддержкой CRUD-операций.

## Установка

### Установка из исходного кода

# Клонирование репозитория
git clone https://github.com/NE1nthegame/project-2_Egorov_M25-555.git
cd project-2_Egorov_M25-555

# Установка зависимостей и пакета
make install
make build
make package-install

## Cсылка на asciinema
https://asciinema.org/a/xqEsokWs2ZzSjJ9Miq3SfuAH0