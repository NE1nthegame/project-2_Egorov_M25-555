#!/usr/bin/env python3

def main():
    print("DB project is running!")

if __name__ == '__main__':
    main()